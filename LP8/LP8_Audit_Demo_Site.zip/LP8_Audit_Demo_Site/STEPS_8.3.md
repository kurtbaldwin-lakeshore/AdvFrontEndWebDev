# DT 8.3 WAI-ARIA and Advanced Accessibility: demo steps

Page: `demos/8.3-aria-demo.html`. Screen reader pass: `before/` vs `after/contact.html`.

## Section A: ARIA describes, it does not behave (slide 8 demo cue)
1. Tab to **Fake button** (`<div role="button" tabindex="0">`). Press Enter and Space. Nothing. Click it with the mouse: works.
2. Tab to **Real button**. Enter and Space both work, no JavaScript for keys.
3. "ARIA is semantics only."

## Section B: aria-labelledby (slide 5 demo cue)
1. Click **Open dialog**. Focus lands inside, Tab stays inside, Escape closes and focus returns to the opener.
2. DevTools, Elements, select the `role="dialog"` div, Accessibility pane: computed name is **Confirm deletion**.
3. Edit the `<h2>` text and look again: the name follows.
4. Decision rule: visible text exists, use `aria-labelledby`. No visible text (icon-only button), use `aria-label`.

## Section C: the aria-label mistake (slide 9 note)
The bad link has visible text "Read our repair guide" but `aria-label="Click here"`. Show the computed name in DevTools: it's "Click here". The good link has no ARIA.

## Section D: aria-live (slide 6)
1. Click **Save**: the polite status text changes, and a screen reader says it after finishing what it is saying.
2. Click **Trigger an error**: the `role="alert"` text is announced immediately.
3. Both regions are empty on load and filled by JavaScript. A region that already has text on load is not announced.

## Section E: icon-only button and sr-only (slides 4 and 6)
Add to cart button (`aria-label`, SVG `aria-hidden="true"`). Stars with `aria-hidden` plus `.sr-only` text. A link with `.sr-only` "(opens in new tab)".

## Screen reader live demo (slide 7, steps 1 to 7)
Use `before/contact.html` and `after/contact.html`.
1. Turn on VoiceOver (Cmd+F5) or NVDA.
2. Open the page. Open the item chooser (VO: Ctrl+Option+U): Headings, Links, Landmarks. Both versions have a skip link, `nav` and `main`.
3. Tab through the form. In `before/`, the Name field has no label: you hear only "edit text" (placeholder). In `after/`, you hear "Your name, edit text, required".
4. Enter a bad email and submit in `after/`: the error is announced and focus moves to the field.
5. Enter a good email and submit: "Message sent. We will reply within two days." is announced by the `role="status"` region.
6. Icon-only button: `demos/8.3-aria-demo.html`, Add to cart.
7. Landmarks: jump between nav, main, footer.
**Not verified:** I could not run a screen reader here. What you will hear varies by screen reader and browser, so listen before you record.
Lighthouse gives `before/contact.html` 100 for accessibility even with the unlabeled field, which makes the "automated tools catch only part" point (slide 8).
