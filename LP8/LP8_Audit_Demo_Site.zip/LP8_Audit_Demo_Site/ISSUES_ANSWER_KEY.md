# Issues seeded in `before/` (answer key)

Matches the six-step audit on the 8.4 slides. Fixed versions are in `after/`.

| Step | Where | Problem | Fix |
|---|---|---|---|
| 1 HTML validator | `index.html`, second card image | `<img>` has no `alt` (also fails Lighthouse "image-alt") | Add descriptive alt |
| 1 HTML validator | `contact.html`, after the form | Stray `</div>` end tag | Delete it |
| 1 HTML validator | `products.html` | Page title in a `<div class="title">`, so no `<h2>`; cards jump from h1 to h3 | Use `<h2>` |
| 2 CSS validator | `css/style.css`, bottom | `colour:` and `margin-botom:` do not exist | Delete the typo rule |
| 3 Contrast | `.price` text | `#9aa59f` on white is 2.54:1 | `#0a3f35` on white (10+:1). Document ratios in a CSS comment |
| 4 Lighthouse | `index.html` hero | 3.9 MB JPEG, `loading="lazy"` on the hero, no `width`/`height` | WebP + `srcset`, no lazy on hero, `fetchpriority="high"`, width/height on every image |
| 4 Lighthouse (SEO) | all pages | Titles "Home" and "Page 2", no meta description, no og tags | Unique 50 to 60 character titles, 150 to 160 character descriptions, og tags |
| 5 Keyboard | `.site-nav a:focus` | `outline: none` hides focus on nav links | `:focus-visible` outline on every interactive element |
| 6 Reduce Motion | `style.css` | h1 `rise` animation and card transitions with no `prefers-reduced-motion` reset | Add the global reset |
| 8.3 screen reader | `contact.html` | Name field has only a placeholder, no `<label>` | Add `<label for>` |
| 8.3 screen reader | `contact.html` | No status message after submit | `role="status"` / `aria-live="polite"` region, plus `role="alert"` for errors |

## Measured scores (Lighthouse 12, `index.html`, served from localhost, headless Chrome)
| | Performance | Accessibility | Best practices | SEO | LCP | CLS |
|---|---|---|---|---|---|---|
| `before/index.html` | 68 | 88 | 96 | 82 | 20.3 s | 0.17 |
| `after/index.html` | 100 | 100 | 100 | 100 | 0.9 s | 0 |

Other pages (performance / accessibility / SEO): `before/products.html` 84 / 93 / 91 (CLS 0.33); `before/contact.html` 100 / 100 / 90; every `after/` page 100 across the board.

Your own numbers will differ a little (machine, Chrome version, throttling). The point is the gap. Note `before/contact.html` scores **100 on accessibility** even though the name input has no label. That is the "automated tools catch only part of it" point from the 8.3 slide.
