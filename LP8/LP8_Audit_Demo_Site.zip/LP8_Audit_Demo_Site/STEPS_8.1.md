# DT 8.1 Web Trends and Performance: demo steps

Pages: `demos/8.1-cls-bad.html`, `8.1-cls-good.html`, `8.1-image-lab.html`; `before/index.html` for the lazy-loading trap.

## 1. Core Web Vitals (slide 3): see LCP and CLS for real
1. Serve `before/` (or put it on GitHub Pages). Open `before/index.html` in Chrome.
2. DevTools, Lighthouse, Performance, Generate report. Read out **LCP** and **CLS** (about 20 s and 0.17 in my run).
3. Open `after/index.html` and run it again (LCP about 0.9 s, CLS 0).
4. Say the thresholds: LCP under 2.5 s, CLS under 0.1, INP under 200 ms. (INP can't be measured by a page load test. It needs interaction.)

## 2. CLS demo (slides 3 and 7)
1. Open `demos/8.1-cls-bad.html`. The "image" arrives 1.5 seconds after the page. Watch the text jump. The live readout shows the layout shift score.
2. View source: the `<img>` has **no** width or height.
3. Open `8.1-cls-good.html`. Same delay. The space is already reserved, no jump, score 0.000.
4. The only difference: `width="800" height="320"`.
- The bad score depends on window size. At about 1280 x 720 it is around 0.1. A shorter window gives a smaller number. Use the visible jump as the main evidence.
- For the real thing on a real page: DevTools, Network, throttling set to **Slow 3G**, reload `before/products.html`. The layout jumps as images arrive (Lighthouse CLS 0.33 for that page).

## 3. Image optimization (slide 4)
1. Open `demos/image-lab/photo-original.jpg`. About 3.9 MB, 4000 x 3000. A stand-in for a phone photo.
2. Go to squoosh.app and drag the file in. Choose WebP at about 80%, resize to 800 wide. Compare. (The pre-made results are `photo-800.webp` at 3.5 KB and `photo-400.webp` at 1.6 KB. This synthetic image compresses far better than a real photo would. A real photo typically drops 60 to 80%.)
3. Open `demos/8.1-image-lab.html`. DevTools, Network tab: compare the two requests.
4. Show the `srcset` and `sizes` attributes on the second image. Resize the window with Network open to see which file loads.

## 4. The lazy-loading trap (slide 7)
1. `before/index.html` has `loading="lazy"` on the hero. Run Lighthouse and show the LCP finding (LCP about 20 s).
2. Open `after/index.html` and show the hero: `fetchpriority="high"`, no `loading` attribute, width and height set. Cards further down have `loading="lazy"`.

## 5. Modern CSS (slide 5)
Nesting, container queries and `:has()` are on the slide only. Nothing in the demo site uses them, so type the examples live in DevTools or a scratch file. I did not build or test a demo for these.
