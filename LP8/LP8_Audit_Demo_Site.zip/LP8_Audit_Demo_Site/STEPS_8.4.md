# DT 8.4 Final Project Audit Prep: demo steps

Run this on `before/`. The seeded problems are in `ISSUES_ANSWER_KEY.md`. The slide's 7 LIVE DEMO steps:

1. **Open your GitHub Pages URL, VS Code and validator.w3.org.** Publish `before/` (or serve it locally). Open `index.html`.
2. **Step 1: validate `index.html`.** Error: img missing `alt` (second card). Fix it. Validate `contact.html` (stray `</div>`) and `products.html` (heading skip). Fix.
3. **Step 2: validate `style.css`** at jigsaw.w3.org/css-validator. Two errors: `colour` and `margin-botom`. Delete the rule. (I checked CSS with the Nu validator's CSS checker, not the W3C CSS validator. Expect the same two errors, but confirm.)
4. **Step 3: WebAIM contrast.** Primary text `#1b2420` on `#f5f6f2` is 14.7:1. The `.price` text `#9aa59f` on white is 2.54:1 (fail). Replace with `#0a3f35`. Add the comment format from the slide notes at the top of `style.css`: `/* Body text #1b2420 on #f5f6f2: 14.7:1 */`. `after/css/style.css` has the full list.
5. **Step 4: Lighthouse on the live URL.** Run before fixes (Performance 68, Accessibility 88, SEO 82 in my local run). Expand the failures: image-alt, color-contrast, meta-description, LCP, CLS. Fix, republish, run again. Screenshot.
6. **Step 5: Tab test.** Tab from the top: the skip link appears first. Tab through the nav in `before/`: the focus ring disappears (`outline: none`). Fix with `:focus-visible`. Count tabs to the first content link: skip link, then Enter goes straight to `main`.
7. **Step 6: Reduce Motion.** Turn on the OS setting (macOS: Accessibility, Display, Reduce motion; Windows: Accessibility, Visual effects, Animation effects off). Reload `before/`: the h1 still slides in and cards still lift. Add the global reset from `after/css/style.css`. Reload: instant.

## SEO checklist (slide 5)
Open `after/index.html` source: title, description, og tags. Paste the live URL into opengraph.xyz.

## Commit history (slide 8)
Not in the demo site. Use a real repo with several commits.

## Notes
- The most missed items from the slides map to this site: reduced motion untested, SEO tags missing, Lighthouse under 90.
- Nothing here uses `grid-template-areas`. The site's grid is `repeat(auto-fit, minmax())`. For the final project the requirement is named areas (see LP6), so don't present this site as the model for that item.
- The final audit also lists "tested with the real OS setting". My tests used browser emulation only.
