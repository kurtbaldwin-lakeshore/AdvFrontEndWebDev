# LP8 Demo: Driftless Cycle Co. Audit Site

| Folder | What it is |
|---|---|
| `before/` | A 3-page Driftless site with problems seeded on purpose. Use it for the 8.4 audit and the 8.3 screen reader demo. |
| `after/` | The same site, fixed. Includes SEO tags, JSON-LD, robots.txt, sitemap.xml and optimized images. Your answer key. |
| `demos/` | Small stand-alone pages for 8.1 to 8.3. |

Guides: `STEPS_8.1.md` to `STEPS_8.4.md`. Answer key: `ISSUES_ANSWER_KEY.md` (don't show students until after the audit).

## Demo pages (`demos/`)
| Page | Use in |
|---|---|
| `8.1-cls-bad.html`, `8.1-cls-good.html` | 8.1 layout shift demo. Image arrives 1.5 s after the page. A live readout shows the layout shift score. |
| `8.1-image-lab.html` | 8.1 image optimization. 3.9 MB original vs 3.5 KB WebP. |
| `8.2-alt-text.html` | 8.2 weak vs good alt text. |
| `8.3-aria-demo.html` | 8.3 `div role="button"`, `aria-labelledby` dialog, `aria-label` mistake, `aria-live`, `.sr-only`. |

## Before you record
- Every page has the skip link in the body and its CSS, and the reduced-motion reset is in `after/` and `demos/`. `before/` leaves it out on purpose (8.4 step 6 finds it).
- To run Lighthouse the way the slides say (on a live URL), put `after/` or `before/` on GitHub Pages. Local files work too: serve the folder (`python -m http.server`) and use `http://localhost:...`, never `file://`.
- The Open Graph tags and `sitemap.xml` use the placeholder `https://YOUR-USERNAME.github.io/driftless-cycle`. Replace it with the real address before you test at opengraph.xyz.
- The images are generated stand-ins: a synthetic "photo" (the hills) and the Driftless bike drawings. The 3.9 MB file is a stand-in for a phone photo.
- Screen reader steps (VoiceOver, NVDA) are manual. I could not test them. The demo page markup was checked with axe and keyboard tests only.
