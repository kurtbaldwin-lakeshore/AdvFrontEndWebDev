# DT 8.2 SEO Fundamentals: demo steps

Pages: `before/` and `after/` side by side; `demos/8.2-alt-text.html`.

## 1. Titles, descriptions and Open Graph (slides 4 and 6)
1. Open `before/index.html`. Tab shows "Home". View source: no description, no og tags.
2. Open `after/index.html`. Tab: "Bikes, Repairs and Group Rides | Driftless Cycle Co.". View source `<head>`: title, `description`, four `og:` tags.
3. Read both titles aloud as a screen reader would announce them on load ("Home" vs the real title). Same element, two audiences.
4. Count characters: the after titles are 52 to 57 characters (page topic first, site name second). The descriptions are 156 to 158.
5. `og:image` points at `images/og-preview.jpg` (1200 x 630). The URL is a placeholder (`YOUR-USERNAME.github.io`). Replace it, publish, then paste the live URL into opengraph.xyz.
6. Lighthouse SEO: `before/index.html` 82, after 100. The Lighthouse "meta description" finding is the visible cause.

## 2. Semantic HTML (slide 5)
`before/products.html` puts the page title in `<div class="title">`. Show it in DevTools, then `after/products.html` with a real `<h2>`. (Lighthouse and the Nu validator both flag the heading level skip.) Also contrast `<article>` and `<time>` from the slide, which the demo site does not use.

## 3. Alt text (slide 6)
Open `demos/8.2-alt-text.html`. Left: `alt="image"` and alt that repeats the caption. Right: describes the picture, caption carries the price.

## 4. Extras in `after/` (not on the slides)
The 8.2 agenda mentions structured data, robots.txt and sitemap.xml, but no slide covers them. `after/` includes all three if you want to show them:
- JSON-LD `BicycleStore` block at the end of `<head>` on `index.html`
- `robots.txt` (allows all, points at the sitemap)
- `sitemap.xml` (three pages)
These use the placeholder URL. Not tested in Google's Rich Results test.
