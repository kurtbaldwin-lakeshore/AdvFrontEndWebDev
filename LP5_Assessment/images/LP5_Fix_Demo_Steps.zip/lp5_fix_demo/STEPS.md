# LP5 live demo: from fixed-width to mobile-first (student submission)

Start in `step0/`. Each later folder is the finished result of that step, so you can
type it live or jump to the snapshot if something goes wrong. `step8/` is the finished page.
The images in these folders are plain placeholders. Copy the student's real
`fair-logo.png`, `cream-puffs.jpg`, `livestock.jpg`, and `ferris-wheel.jpg` into the folder you demo from.

Before you start: open `step0/index.html`, press F12, and turn on the device toolbar (Ctrl+Shift+M).
Pick a phone width (375px) and drag it wider.

## Step 0: Show the problem (no typing)
At 375px the page scrolls sideways. Drag wider and nothing changes at 600px or 1024px.
Ask: "Why don't the media queries do anything?" Answer: `.site-nav` is not a flex container and
`.schedule-card` is not a grid, so `flex-direction` and `grid-template-columns` have nothing to act on.
Also point out `.layout { width: 960px }`, the two `float: left` columns, and the fixed widths.

## Step 1: Add the viewport meta tag (index.html)
In `<head>`, after the charset line:

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

Without it, a real phone pretends to be about 980px wide and the media queries never fire.

## Step 2: Make the base layout the phone layout (style.css)
Replace the whole "Two fixed-width columns using float" block with:

    /* Mobile first: one column. .layout is the flex container.
       No fixed widths and no floats. */
    .layout {
      display: flex;
      flex-direction: column;
    }

    .content {
      padding: 24px;
    }

    .sidebar {
      padding: 24px;
      background: #f4ede1;
    }

Result: the sideways scroll is gone and the sidebar stacks under the content.

## Step 3: Make the nav a flex container and fix the 600px query
Add to `.site-nav`:

    display: flex;
    flex-direction: column;     /* phone: links stack */
    gap: 8px;

Delete `margin-right: 24px;` from `.site-nav a` (the gap replaces it).
Replace both media queries (delete the two `grid-template-columns` lines) with:

    @media (min-width: 600px) {
      .site-nav {
        flex-direction: row;
        gap: 24px;
      }
    }

    @media (min-width: 1024px) {
    }

Result: links stack on a phone and sit in a row from 600px up. Their original rule now works
because the nav is finally a flex container.

## Step 4: Cards go two per row at 600px (inside the 600px query)

    .content {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
    }

    .content h2 {
      flex: 1 1 100%;
      margin: 0;
    }

    .schedule-card {
      flex: 1 1 280px;
      margin-bottom: 0;
    }

Result: 1 card per row on a phone, 2 at 800px. Tie back to 5.2: `flex: 1 1 280px`
means "start at 280px, grow to share the row, wrap when there is no room."

## Step 5: Sidebar moves beside the content at 1024px (inside the 1024px query)

    .layout {
      flex-direction: row;
    }

    .content {
      flex: 3;
    }

    .sidebar {
      flex: 1;
    }

Result: at 1024px and up, content and sidebar sit side by side (3 : 1). The cards inside
re-flow to 3 per row at 1280px with no extra code.

## Step 6: Fix the fluid heading
Change the h1 size from `clamp(1rem, 4vw, 1.2rem)` to:

    font-size: clamp(1.75rem, 1.2rem + 3vw, 3rem);

The old values only ranged from 16px to 19.2px, so the h1 came out smaller than the tagline.
Now it is about 30px on a phone and 48px on a desktop.

## Step 7: Tidy up
- Delete the stale "Fixed pixel width..." comments and update the top-of-file comment.
- Remove the extra leading spaces before the first `*` selector.
- `.ticket-btn`: change `display: flex; flex-wrap: wrap;` to `display: inline-block;`.
- Swap the reduced-motion body for the course-standard reset:

      @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after {
          animation-duration: 0.01ms !important;
          animation-iteration-count: 1 !important;
          transition-duration: 0.01ms !important;
        }
      }

## Step 8: Skip link (index.html and style.css)
First line inside `<body>`:

    <a class="skip-link" href="#main-content">Skip to main content</a>

Add `id="main-content"` to `<main class="content">`, and add this CSS (above `.page`):

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      z-index: 10;
      padding: 8px 16px;
      background: #000;
      color: #fff;
    }

    .skip-link:focus {
      left: 0;
    }

Press Tab once on the page to show it appear.

## Step 9: Validate (do this live)
1. W3C CSS validator: https://jigsaw.w3.org/css-validator/ (paste or upload `style.css`). Expect zero errors.
   If it flags the `clamp()` line, that is a known false alarm in some older validators. Show the Nu HTML checker too.
2. Lighthouse: DevTools > Lighthouse > Accessibility only > Analyze. Expect 90 or higher.
   Save a screenshot of both for the assignment.
